<?php
namespace Database\Seeders;
use Illuminate\Database\Seeder;
use App\Models\{Room, Section, Package, Child};


class DemoSeed extends Seeder {
    public function run(): void {

    }
}
